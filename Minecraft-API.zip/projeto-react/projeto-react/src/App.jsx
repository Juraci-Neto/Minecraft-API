import React, { useState } from 'react';
import AuthScreen from './components/AuthScreen';
import Header from './components/Header';
import PlayerSkinCard from './components/PlayerSkinCard';
import ServerMonitorCard from './components/ServerMonitorCard';

const DEMO_USER = {
  email: 'demo@minecraft.org',
  password: 'demopassword123',
};

export default function App() {
  // Armazenamento local apenas durante a execução (em memória)
  const [registeredUsers, setRegisteredUsers] = useState([DEMO_USER]);
  const [currentUserEmail, setCurrentUserEmail] = useState('');

  const isAuthenticated = Boolean(currentUserEmail);

  const handleRegisterUser = (newUser) => {
    setRegisteredUsers((prev) => [...prev, newUser]);
  };

  const handleAuthenticate = (email) => {
    setCurrentUserEmail(email);
  };

  const handleDemoLogin = () => {
    setCurrentUserEmail(DEMO_USER.email);
  };

  const handleLogout = () => {
    setCurrentUserEmail('');
  };

  if (!isAuthenticated) {
    return (
      <AuthScreen
        registeredUsers={registeredUsers}
        onRegisterUser={handleRegisterUser}
        onAuthenticate={handleAuthenticate}
        onDemoLogin={handleDemoLogin}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-6 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        <Header userEmail={currentUserEmail} onLogout={handleLogout} />
        <PlayerSkinCard isAuthenticated={isAuthenticated} />
        <ServerMonitorCard isAuthenticated={isAuthenticated} />
      </div>
    </div>
  );
}