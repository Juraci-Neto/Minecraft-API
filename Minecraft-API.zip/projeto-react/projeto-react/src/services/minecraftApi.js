export async function fetchPlayerSkinBlobs(username, edition) {
  const cleanUser = encodeURIComponent(username.trim());
  const editionPath = edition === 'JAVA' ? 'JAVA' : 'BEDROCK';

  const faceEndpoint = `https://mc-api.io/render/FACE/${cleanUser}/${editionPath}?size=256`;
  const bodyEndpoint = `https://mc-api.io/render/FULL/${cleanUser}/${editionPath}?size=256`;

  let faceUrl = `https://mc-heads.net/avatar/${cleanUser}/256`;
  let bodyUrl = `https://mc-heads.net/body/${cleanUser}/256`;

  try {
    const resFace = await fetch(faceEndpoint);
    if (resFace.ok) {
      const blobFace = await resFace.blob();
      faceUrl = URL.createObjectURL(blobFace);
    }
  } catch {
    // Mantém fallback mc-heads.net
  }

  try {
    const resBody = await fetch(bodyEndpoint);
    if (resBody.ok) {
      const blobBody = await resBody.blob();
      bodyUrl = URL.createObjectURL(blobBody);
    }
  } catch {
    // Mantém fallback mc-heads.net
  }

  return { faceUrl, bodyUrl };
}

export async function fetchMinecraftServerStatus(ip, type) {
  let cleanIp = ip.trim();
  if (!cleanIp) {
    throw new Error('Informe um IP ou domínio válido.');
  }

  if (type === 'BEDROCK' && !cleanIp.includes(':')) {
    cleanIp = `${cleanIp}:19132`;
  }

  const editionPath = type === 'BEDROCK' ? 'bedrock' : 'java';
  const endpoint = `https://api.mcstatus.io/v2/status/${editionPath}/${encodeURIComponent(cleanIp)}`;

  const res = await fetch(endpoint);
  if (!res.ok) {
    throw new Error('Servidor não encontrado ou resposta inválida da API.');
  }

  const data = await res.json();

  if (!data.online) {
    throw new Error(`O servidor ${type} (${cleanIp}) está offline ou inacessível.`);
  }

  return {
    hostname: data.host || cleanIp,
    port: data.port || (type === 'BEDROCK' ? 19132 : 25565),
    online: data.online,
    version: data.version?.name_clean || data.version?.name || `${type} Edition`,
    onlinePlayers: data.players?.online ?? 0,
    maxPlayers: data.players?.max ?? 0,
    rawMotd: data.motd?.clean ? data.motd.clean.replace(/\n/g, ' ') : 'Sem descrição',
    favicon: data.icon || null,
    ping: data.round_trip_latency ?? 20,
  };
}