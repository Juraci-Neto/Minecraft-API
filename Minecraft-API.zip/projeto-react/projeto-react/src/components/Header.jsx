import React from 'react';

export default function Header({ userEmail, onLogout }) {
  return (
    <header className="flex flex-col md:flex-row justify-between items-center bg-slate-900 p-6 border border-slate-800 rounded-2xl gap-4 shadow-xl">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-emerald-500/20 border border-emerald-500/40 rounded-xl flex items-center justify-center text-xl">
          🧱
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-emerald-400">Minecraft API Explorer</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Conectado como: <span className="text-slate-200 font-semibold">{userEmail}</span>
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={onLogout}
        className="bg-slate-800 hover:bg-red-950/60 text-slate-300 hover:text-red-300 border border-slate-700 hover:border-red-800/80 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-sm"
      >
        Sair da Conta
      </button>
    </header>
  );
}