import React, { useState } from 'react';

export default function AuthScreen({ registeredUsers, onRegisterUser, onAuthenticate, onDemoLogin }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [feedback, setFeedback] = useState({ type: '', message: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    if (!cleanEmail || !cleanPassword) return;

    if (mode === 'register') {
      const alreadyExists = registeredUsers.some((u) => u.email === cleanEmail);
      if (alreadyExists) {
        setFeedback({
          type: 'error',
          message: 'Este e-mail já foi cadastrado nesta sessão. Faça login.',
        });
        return;
      }

      onRegisterUser({ email: cleanEmail, password: cleanPassword });
      setFeedback({ type: '', message: '' });
      onAuthenticate(cleanEmail);
      return;
    }

    // Modo login
    const foundUser = registeredUsers.find((u) => u.email === cleanEmail);
    if (!foundUser) {
      setFeedback({
        type: 'error',
        message: 'Usuário não encontrado na sessão atual. Cadastre-se ou use a conta demo.',
      });
      return;
    }

    if (foundUser.password !== cleanPassword) {
      setFeedback({
        type: 'error',
        message: 'Senha incorreta para este e-mail.',
      });
      return;
    }

    setFeedback({ type: '', message: '' });
    onAuthenticate(foundUser.email);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans">
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl max-w-md w-full shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <span className="text-3xl">🧱</span>
          </div>
          <h1 className="text-3xl font-extrabold text-emerald-400">Minecraft API Explorer</h1>
          <p className="text-sm text-slate-400">
            {mode === 'login'
              ? 'Entre com sua conta da sessão atual'
              : 'Crie uma conta temporária para esta execução'}
          </p>
        </div>

        {/* Alternador Login / Cadastro */}
        <div className="grid grid-cols-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setFeedback({ type: '', message: '' });
            }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'login' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Login
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setFeedback({ type: '', message: '' });
            }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'register' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cadastro
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">E-mail</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu.email@exemplo.com"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500 transition-all text-sm"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Senha</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-slate-100 focus:outline-none focus:border-emerald-500 transition-all text-sm"
            />
          </div>

          {feedback.message && (
            <div className="bg-red-950/50 border border-red-800/80 text-red-300 px-3.5 py-2.5 rounded-xl text-xs">
              {feedback.message}
            </div>
          )}

          <button
            type="submit"
            className={`w-full font-bold py-3 rounded-xl transition-all shadow-lg cursor-pointer text-sm text-white ${
              mode === 'login'
                ? 'bg-emerald-600 hover:bg-emerald-500 hover:shadow-emerald-900/40'
                : 'bg-cyan-600 hover:bg-cyan-500 hover:shadow-cyan-900/40'
            }`}
          >
            {mode === 'login' ? 'Entrar' : 'Cadastrar e Entrar'}
          </button>
        </form>

        <div className="pt-2 border-t border-slate-800/80 flex flex-col items-center gap-2 text-center">
          <p className="text-[11px] text-slate-500">
            Contas cadastradas na sessão atual: <span className="text-slate-300 font-semibold">{registeredUsers.length}</span>
          </p>
          <button
            type="button"
            onClick={onDemoLogin}
            className="text-xs text-slate-400 hover:text-emerald-400 underline transition-colors cursor-pointer"
          >
            Continuar com conta de teste de demonstração
          </button>
        </div>
      </div>
    </div>
  );
}