import React, { useState, useEffect } from 'react';
import { fetchPlayerSkinBlobs } from '../services/minecraftApi';

export default function PlayerSkinCard({ isAuthenticated }) {
  const [playerEdition, setPlayerEdition] = useState('JAVA');
  const [usernameInput, setUsernameInput] = useState('ByteException_');
  const [activeUsername, setActiveUsername] = useState('ByteException_');
  const [activePlayerEdition, setActivePlayerEdition] = useState('JAVA');

  const [faceBlobUrl, setFaceBlobUrl] = useState('');
  const [bodyBlobUrl, setBodyBlobUrl] = useState('');
  const [skinLoading, setSkinLoading] = useState(false);

  const handleFetchPlayer = (e) => {
    e.preventDefault();
    if (!usernameInput.trim()) return;
    setActiveUsername(usernameInput.trim());
    setActivePlayerEdition(playerEdition);
  };

  useEffect(() => {
    if (!isAuthenticated) return;

    let isMounted = true;
    let createdFace = '';
    let createdBody = '';

    setSkinLoading(true);

    fetchPlayerSkinBlobs(activeUsername, activePlayerEdition)
      .then(({ faceUrl, bodyUrl }) => {
        if (!isMounted) return;
        if (faceUrl.startsWith('blob:')) createdFace = faceUrl;
        if (bodyUrl.startsWith('blob:')) createdBody = bodyUrl;
        setFaceBlobUrl(faceUrl);
        setBodyBlobUrl(bodyUrl);
      })
      .finally(() => {
        if (isMounted) setSkinLoading(false);
      });

    return () => {
      isMounted = false;
      if (createdFace) URL.revokeObjectURL(createdFace);
      if (createdBody) URL.revokeObjectURL(createdBody);
    };
  }, [activeUsername, activePlayerEdition, isAuthenticated]);

  return (
    <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-cyan-400 flex items-center gap-2">
            <span>🔎</span> Consulta de Jogador & Skins
          </h2>
          <p className="text-xs text-slate-400 mt-1">Busque avatares e renders 3D de contas Java e Bedrock</p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setPlayerEdition('JAVA');
              setUsernameInput('ByteException_');
            }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              playerEdition === 'JAVA' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Java
          </button>
          <button
            type="button"
            onClick={() => {
              setPlayerEdition('BEDROCK');
              setUsernameInput('Steve');
            }}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              playerEdition === 'BEDROCK' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Bedrock
          </button>
        </div>
      </div>

      <form onSubmit={handleFetchPlayer} className="flex gap-3">
        <input
          type="text"
          value={usernameInput}
          onChange={(e) => setUsernameInput(e.target.value)}
          placeholder={playerEdition === 'JAVA' ? 'Nick Java (ex: ByteException_)' : 'Gamertag Bedrock (ex: Steve)'}
          className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-slate-100 text-sm focus:outline-none focus:border-cyan-500 transition-all"
        />
        <button
          type="submit"
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-all shadow-md cursor-pointer"
        >
          Pesquisar
        </button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center bg-slate-950/60 p-6 rounded-xl border border-slate-800/80 mt-4 relative">
        {skinLoading && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center rounded-xl z-20 text-cyan-400 text-xs font-bold">
            A carregar skins...
          </div>
        )}

        <div className="flex flex-col items-center">
          <span className="text-xs text-slate-400 mb-3 font-semibold bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            Avatar / Rosto ({activePlayerEdition})
          </span>
          {faceBlobUrl ? (
            <img
              src={faceBlobUrl}
              alt={`Face de ${activeUsername}`}
              className="w-28 h-28 rounded-xl shadow-lg border-2 border-slate-700 bg-slate-900 object-contain p-1"
            />
          ) : (
            <div className="w-28 h-28 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-xs text-slate-500">
              Sem Imagem
            </div>
          )}
        </div>

        <div className="flex flex-col items-center">
          <span className="text-xs text-slate-400 mb-3 font-semibold bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            Render 3D Completo ({activePlayerEdition})
          </span>
          {bodyBlobUrl ? (
            <img
              src={bodyBlobUrl}
              alt={`Body 3D de ${activeUsername}`}
              className="h-48 object-contain drop-shadow-2xl"
            />
          ) : (
            <div className="h-48 w-24 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-xs text-slate-500">
              Sem Imagem
            </div>
          )}
        </div>
      </div>
    </section>
  );
}