import React, { useState, useEffect, useCallback } from 'react';
import { fetchMinecraftServerStatus } from '../services/minecraftApi';

export default function ServerMonitorCard({ isAuthenticated }) {
  const [serverType, setServerType] = useState('JAVA');
  const [serverIpInput, setServerIpInput] = useState('hypixel.net');
  const [serverData, setServerData] = useState(null);
  const [serverError, setServerError] = useState('');
  const [serverLoading, setServerLoading] = useState(false);

  const loadServer = useCallback(async (ip, type) => {
    setServerLoading(true);
    setServerError('');
    try {
      const info = await fetchMinecraftServerStatus(ip, type);
      setServerData(info);
    } catch (err) {
      setServerError(err.message || 'Erro ao conectar ao servidor.');
    } finally {
      setServerLoading(false);
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    loadServer(serverIpInput, serverType);
  };

  useEffect(() => {
    if (isAuthenticated && !serverData && !serverLoading) {
      loadServer('hypixel.net', 'JAVA');
    }
  }, [isAuthenticated, serverData, serverLoading, loadServer]);

  return (
    <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-emerald-400 flex items-center gap-2">
            <span>🌐</span> Monitor de Servidor
          </h2>
          <p className="text-xs text-slate-400 mt-1">Verifique ping, jogadores online e MOTD em tempo real</p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setServerType('JAVA');
              setServerIpInput('hypixel.net');
              loadServer('hypixel.net', 'JAVA');
            }}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              serverType === 'JAVA' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Java Edition
          </button>
          <button
            type="button"
            onClick={() => {
              setServerType('BEDROCK');
              setServerIpInput('geo.hivebedrock.network');
              loadServer('geo.hivebedrock.network', 'BEDROCK');
            }}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              serverType === 'BEDROCK' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Bedrock Edition
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="flex gap-3">
        <input
          type="text"
          value={serverIpInput}
          onChange={(e) => setServerIpInput(e.target.value)}
          placeholder={serverType === 'JAVA' ? 'IP Java (ex: hypixel.net)' : 'IP Bedrock (ex: geo.hivebedrock.network)'}
          className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-slate-100 text-sm focus:outline-none focus:border-emerald-500 transition-all"
        />
        <button
          type="submit"
          disabled={serverLoading}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-all shadow-md disabled:opacity-50 cursor-pointer"
        >
          {serverLoading ? 'A verificar...' : `Consultar ${serverType}`}
        </button>
      </form>

      {serverError && (
        <div className="bg-red-950/40 border border-red-800/80 text-red-300 p-4 rounded-xl text-sm flex items-center gap-3">
          <span className="text-lg">⚠️</span>
          <div>{serverError}</div>
        </div>
      )}

      {serverData && (
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <div className="flex items-center gap-3">
              {serverData.favicon ? (
                <img
                  src={serverData.favicon}
                  alt="Ícone"
                  className="w-12 h-12 rounded-lg border border-slate-800 bg-slate-900 object-contain"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-xs text-slate-400 font-bold">
                  {serverType}
                </div>
              )}
              <div>
                <h3 className="font-bold text-lg text-slate-100">{serverData.hostname}</h3>
                <p className="text-xs text-slate-400">
                  Tipo: <span className="text-cyan-400 font-medium">{serverType}</span> | Porta:{' '}
                  <span className="text-slate-300 font-mono">{serverData.port}</span> | Ping:{' '}
                  <span className="text-emerald-400 font-mono">{serverData.ping}ms</span>
                </p>
              </div>
            </div>
            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                serverData.online
                  ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                  : 'bg-red-950/80 text-red-400 border border-red-800'
              }`}
            >
              {serverData.online ? '🟢 Online' : '🔴 Offline'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80">
              <span className="text-xs text-slate-500 block mb-1">Versão</span>
              <span className="font-mono text-cyan-300 text-xs truncate block">{serverData.version}</span>
            </div>
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80">
              <span className="text-xs text-slate-500 block mb-1">Jogadores Online</span>
              <span className="font-mono text-emerald-300 text-xs font-semibold">
                {serverData.onlinePlayers} / {serverData.maxPlayers}
              </span>
            </div>
            <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80">
              <span className="text-xs text-slate-500 block mb-1">MOTD (Mensagem)</span>
              <span className="font-mono text-slate-300 text-xs truncate block" title={serverData.rawMotd}>
                {serverData.rawMotd}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}